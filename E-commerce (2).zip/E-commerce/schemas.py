from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime
from models import ProductType, DurationType, RenewalType


# ==================== PRODUCT SCHEMAS ====================


class ProductBase(BaseModel):
    name: str
    base_price: float
    discount: Optional[float] = 0
    tax: Optional[float] = 0


class PhysicalProductCreate(ProductBase):
    weight: float
    stock: int = 0
    warehouse: Optional[str] = None


class DigitalProductCreate(ProductBase):
    file_size: float
    download_link: str


class SubscriptionProductCreate(ProductBase):
    duration: DurationType
    auto_renewal: RenewalType
    trial_period: Optional[int] = 0


class ProductResponse(BaseModel):
    id: int
    product_type: ProductType
    name: str
    base_price: float
    discount: float
    tax: float
    created_at: datetime

    class Config:
        from_attributes = True


class PhysicalProductResponse(BaseModel):
    id: int
    product_type: ProductType
    name: str
    base_price: float
    discount: float
    tax: float
    weight: float
    stock: int
    warehouse: Optional[str] = None

    class Config:
        from_attributes = True


class DigitalProductResponse(BaseModel):
    id: int
    product_type: ProductType
    name: str
    base_price: float
    discount: float
    tax: float
    file_size: float
    download_link: str
    license_key: str
    delivery: str

    class Config:
        from_attributes = True


class SubscriptionProductResponse(BaseModel):
    id: int
    product_type: ProductType
    name: str
    base_price: float
    discount: float
    tax: float
    duration: DurationType
    auto_renewal: RenewalType
    trial_period: int
    activation_date: datetime
    expiry_date: datetime
    recurring_billing: str

    class Config:
        from_attributes = True


# ==================== ORDER SCHEMAS ====================


class OrderItemBase(BaseModel):
    product_id: int
    quantity: int


class OrderItemResponse(BaseModel):
    id: int
    product_id: int
    quantity: int
    price_at_purchase: float

    class Config:
        from_attributes = True


class OrderCreate(BaseModel):
    customer_name: str
    customer_email: EmailStr
    items: List[OrderItemBase]


class OrderResponse(BaseModel):
    id: int
    order_id: str
    customer_name: str
    customer_email: str
    total_amount: float
    order_date: datetime
    status: str

    class Config:
        from_attributes = True


class OrderDetailResponse(OrderResponse):
    """Optional: use this if you also want to return line items with the order"""

    order_items: List[OrderItemResponse] = []

    class Config:
        from_attributes = True
