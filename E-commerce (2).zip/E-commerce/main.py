from fastapi import FastAPI, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
import logging

from database import engine, Base, get_db
from models import ProductType
import crud
from schemas import (
    PhysicalProductCreate,
    PhysicalProductResponse,
    DigitalProductCreate,
    DigitalProductResponse,
    SubscriptionProductCreate,
    SubscriptionProductResponse,
    OrderCreate,
    OrderResponse,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="E-Commerce API",
    description="Simple E-Commerce Store API",
    version="1.0.0",
)


# ==================== VALIDATION HELPERS ====================

def validate_price(price: float):
    if price is None or price <= 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Price must be greater than 0",
        )


def validate_discount(discount: float):
    if discount is not None and not (0 <= discount <= 100):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Discount must be between 0 and 100",
        )


def validate_tax(tax: float):
    if tax is not None and tax < 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Tax cannot be negative",
        )


def serialize_product(product):
    product_data = {
        "id": product.id,
        "type": product.product_type.value,
        "name": product.name,
        "base_price": product.base_price,
        "discount": product.discount,
        "tax": product.tax,
    }

    if product.product_type == ProductType.PHYSICAL:
        phys = product.physical_product
        if not phys:
            product_data["details_missing"] = True
            return product_data
        product_data.update(
            {
                "weight": phys.weight,
                "stock": phys.stock,
                "warehouse": phys.warehouse,
            }
        )
    elif product.product_type == ProductType.DIGITAL:
        dig = product.digital_product
        if not dig:
            product_data["details_missing"] = True
            return product_data
        product_data.update(
            {
                "file_size": dig.file_size,
                "download_link": dig.download_link,
                "license_key": dig.license_key,
                "delivery": dig.delivery(),
            }
        )
    elif product.product_type == ProductType.SUBSCRIPTION:
        sub = product.subscription_product
        if not sub:
            product_data["details_missing"] = True
            return product_data
        product_data.update(
            {
                "duration": sub.duration,
                "auto_renewal": sub.auto_renewal,
                "trial_period": sub.trial_period,
                "activation_date": sub.activation_date,
                "expiry_date": sub.expiry_date,
                "recurring_billing": sub.recurring_billing(),
            }
        )

    return product_data


# ==================== PHYSICAL PRODUCT ENDPOINTS ====================

@app.post(
    "/products/physical",
    response_model=PhysicalProductResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Physical Products"],
)
def create_physical_product(product: PhysicalProductCreate, db: Session = Depends(get_db)):
    try:
        validate_price(product.base_price)
        validate_discount(product.discount)
        validate_tax(product.tax)

        logger.info(f"Creating physical product: {product.name}")
        db_product = crud.create_physical_product(db, product)
        db_physical = db_product.physical_product
        return {
            "id": db_product.id,
            "product_type": db_product.product_type,
            "name": db_product.name,
            "base_price": db_product.base_price,
            "discount": db_product.discount,
            "tax": db_product.tax,
            "weight": db_physical.weight,
            "stock": db_physical.stock,
            "warehouse": db_physical.warehouse,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating physical product: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error creating product",
        )


@app.put(
    "/products/physical/{product_id}",
    tags=["Physical Products"],
)
def update_physical_product(
    product_id: int, product: PhysicalProductCreate, db: Session = Depends(get_db)
):
    try:
        validate_price(product.base_price)
        validate_discount(product.discount)
        validate_tax(product.tax)

        db_product = (
            db.query(crud.Product)
            .filter(crud.Product.id == product_id, crud.Product.product_type == ProductType.PHYSICAL)
            .first()
        )
        if not db_product:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")

        logger.info(f"Updating physical product: {product_id}")
        db_physical = db_product.physical_product
        db_physical.weight = product.weight
        db_physical.stock = product.stock
        db_physical.warehouse = product.warehouse

        crud.update_product(
            db,
            product_id,
            name=product.name,
            base_price=product.base_price,
            discount=product.discount,
            tax=product.tax,
        )
        db.commit()

        return {"message": "Product updated successfully", "product_id": product_id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating physical product: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error updating product",
        )


@app.get(
    "/products/physical/{product_id}",
    response_model=PhysicalProductResponse,
    tags=["Physical Products"],
)
def get_physical_product(product_id: int, db: Session = Depends(get_db)):
    try:
        db_product = (
            db.query(crud.Product)
            .filter(crud.Product.id == product_id, crud.Product.product_type == ProductType.PHYSICAL)
            .first()
        )
        if not db_product:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")

        db_physical = db_product.physical_product
        if not db_physical:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Physical product details not found",
            )

        return {
            "id": db_product.id,
            "product_type": db_product.product_type,
            "name": db_product.name,
            "base_price": db_product.base_price,
            "discount": db_product.discount,
            "tax": db_product.tax,
            "weight": db_physical.weight,
            "stock": db_physical.stock,
            "warehouse": db_physical.warehouse,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving physical product: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error retrieving product",
        )


# ==================== DIGITAL PRODUCT ENDPOINTS ====================

@app.post(
    "/products/digital",
    response_model=DigitalProductResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Digital Products"],
)
def create_digital_product(product: DigitalProductCreate, db: Session = Depends(get_db)):
    try:
        validate_price(product.base_price)
        validate_discount(product.discount)
        validate_tax(product.tax)

        logger.info(f"Creating digital product: {product.name}")
        db_product = crud.create_digital_product(db, product)
        db_digital = db_product.digital_product
        return {
            "id": db_product.id,
            "product_type": db_product.product_type,
            "name": db_product.name,
            "base_price": db_product.base_price,
            "discount": db_product.discount,
            "tax": db_product.tax,
            "file_size": db_digital.file_size,
            "download_link": db_digital.download_link,
            "license_key": db_digital.license_key,
            "delivery": db_digital.delivery(),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating digital product: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error creating product",
        )


@app.get(
    "/products/digital/{product_id}",
    response_model=DigitalProductResponse,
    tags=["Digital Products"],
)
def get_digital_product(product_id: int, db: Session = Depends(get_db)):
    try:
        db_product = (
            db.query(crud.Product)
            .filter(crud.Product.id == product_id, crud.Product.product_type == ProductType.DIGITAL)
            .first()
        )
        if not db_product:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")

        db_digital = db_product.digital_product
        return {
            "id": db_product.id,
            "product_type": db_product.product_type,
            "name": db_product.name,
            "base_price": db_product.base_price,
            "discount": db_product.discount,
            "tax": db_product.tax,
            "file_size": db_digital.file_size,
            "download_link": db_digital.download_link,
            "license_key": db_digital.license_key,
            "delivery": db_digital.delivery(),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving digital product: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error retrieving product",
        )


# ==================== SUBSCRIPTION PRODUCT ENDPOINTS ====================

@app.post(
    "/products/subscription",
    response_model=SubscriptionProductResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Subscription Products"],
)
def create_subscription_product(product: SubscriptionProductCreate, db: Session = Depends(get_db)):
    try:
        validate_price(product.base_price)
        validate_discount(product.discount)
        validate_tax(product.tax)

        logger.info(f"Creating subscription product: {product.name}")
        db_product = crud.create_subscription_product(db, product)
        db_subscription = db_product.subscription_product
        return {
            "id": db_product.id,
            "product_type": db_product.product_type,
            "name": db_product.name,
            "base_price": db_product.base_price,
            "discount": db_product.discount,
            "tax": db_product.tax,
            "duration": db_subscription.duration,
            "auto_renewal": db_subscription.auto_renewal,
            "trial_period": db_subscription.trial_period,
            "activation_date": db_subscription.activation_date,
            "expiry_date": db_subscription.expiry_date,
            "recurring_billing": db_subscription.recurring_billing(),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating subscription product: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error creating product",
        )


@app.get(
    "/products/subscription/{product_id}",
    response_model=SubscriptionProductResponse,
    tags=["Subscription Products"],
)
def get_subscription_product(product_id: int, db: Session = Depends(get_db)):
    try:
        db_product = (
            db.query(crud.Product)
            .filter(crud.Product.id == product_id, crud.Product.product_type == ProductType.SUBSCRIPTION)
            .first()
        )
        if not db_product:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")

        db_subscription = db_product.subscription_product
        return {
            "id": db_product.id,
            "product_type": db_product.product_type,
            "name": db_product.name,
            "base_price": db_product.base_price,
            "discount": db_product.discount,
            "tax": db_product.tax,
            "duration": db_subscription.duration,
            "auto_renewal": db_subscription.auto_renewal,
            "trial_period": db_subscription.trial_period,
            "activation_date": db_subscription.activation_date,
            "expiry_date": db_subscription.expiry_date,
            "recurring_billing": db_subscription.recurring_billing(),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving subscription product: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error retrieving product",
        )


# ==================== GENERAL PRODUCT ENDPOINTS ====================

@app.get("/products", tags=["Products"])
def list_all_products(
    skip: int = Query(0, ge=0),
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
):
    try:
        logger.info(f"Fetching products: skip={skip}, limit={limit}")
        products = crud.get_all_products(db, skip=skip, limit=limit)

        return [serialize_product(product) for product in products]
    except Exception as e:
        logger.error(f"Error fetching products: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching products",
        )


@app.get("/products/type/{product_type}", tags=["Products"])
def get_products_by_type(
    product_type: str,
    skip: int = Query(0, ge=0),
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
):
    try:
        valid_types = ["physical", "digital", "subscription"]
        if product_type.lower() not in valid_types:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Product type must be one of: {', '.join(valid_types)}",
            )

        enum_type = ProductType(product_type.lower())
        products = crud.get_products_by_type(db, enum_type, skip=skip, limit=limit)

        return [{"id": p.id, "name": p.name, "type": p.product_type.value} for p in products]
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching products by type: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching products",
        )


@app.get("/products/{product_id}", tags=["Products"])
def get_product(product_id: int, db: Session = Depends(get_db)):
    try:
        logger.info(f"Fetching product: {product_id}")
        product = crud.get_product_by_id(db, product_id)
        if not product:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")

        return serialize_product(product)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching product: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching product",
        )


@app.delete("/products/{product_id}", tags=["Products"])
def delete_product(product_id: int, db: Session = Depends(get_db)):
    try:
        logger.info(f"Deleting product: {product_id}")
        if not crud.delete_product(db, product_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")
        return {"message": "Product deleted successfully", "product_id": product_id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting product: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error deleting product",
        )


# ==================== ORDER ENDPOINTS ====================

@app.post(
    "/orders",
    response_model=OrderResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Orders"],
)
def create_order(order: OrderCreate, db: Session = Depends(get_db)):
    try:
        if not order.items:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Order must contain at least one item",
            )

        for item in order.items:
            if item.quantity <= 0:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Quantity must be greater than 0",
                )

        logger.info(f"Creating order for customer: {order.customer_name}")
        db_order = crud.create_order(db, order)

        if not db_order:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Failed to create order")

        return {
            "id": db_order.id,
            "order_id": db_order.order_id,
            "customer_name": db_order.customer_name,
            "customer_email": db_order.customer_email,
            "total_amount": db_order.total_amount,
            "order_date": db_order.order_date,
            "status": db_order.status,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating order: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error creating order: {str(e)}",
        )


@app.get("/orders/{order_id}", response_model=OrderResponse, tags=["Orders"])
def get_order(order_id: str, db: Session = Depends(get_db)):
    try:
        db_order = crud.get_order_by_order_id(db, order_id)
        if not db_order:
            logger.warning(f"Order not found: {order_id}")
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Order not found")

        return {
            "id": db_order.id,
            "order_id": db_order.order_id,
            "customer_name": db_order.customer_name,
            "customer_email": db_order.customer_email,
            "total_amount": db_order.total_amount,
            "order_date": db_order.order_date,
            "status": db_order.status,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving order: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error retrieving order",
        )


@app.get("/orders", tags=["Orders"])
def list_orders(
    skip: int = Query(0, ge=0),
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
):
    try:
        logger.info(f"Fetching orders: skip={skip}, limit={limit}")
        orders = crud.get_all_orders(db, skip=skip, limit=limit)
        return [
            {
                "id": order.id,
                "order_id": order.order_id,
                "customer_name": order.customer_name,
                "customer_email": order.customer_email,
                "total_amount": order.total_amount,
                "order_date": order.order_date,
                "status": order.status,
            }
            for order in orders
        ]
    except Exception as e:
        logger.error(f"Error fetching orders: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching orders",
        )


@app.put("/orders/{order_id}/status", tags=["Orders"])
def update_order_status_endpoint(order_id: str, new_status: str, db: Session = Depends(get_db)):
    try:
        valid_statuses = ["pending", "confirmed", "shipped", "delivered", "cancelled"]
        if new_status.lower() not in valid_statuses:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Status must be one of: {', '.join(valid_statuses)}",
            )

        db_order = crud.get_order_by_order_id(db, order_id)
        if not db_order:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Order not found")

        logger.info(f"Updating order {order_id} status to {new_status}")
        crud.update_order_status(db, db_order.id, new_status)

        return {
            "message": "Order status updated successfully",
            "order_id": order_id,
            "new_status": new_status,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating order status: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error updating order",
        )


@app.delete("/orders/{order_id}", tags=["Orders"])
def delete_order(order_id: str, db: Session = Depends(get_db)):
    try:
        db_order = crud.get_order_by_order_id(db, order_id)
        if not db_order:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Order not found")

        logger.info(f"Deleting order: {order_id}")
        db.delete(db_order)
        db.commit()

        return {"message": "Order deleted successfully", "order_id": order_id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting order: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error deleting order",
        )
