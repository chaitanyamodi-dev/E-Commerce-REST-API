from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Enum
from sqlalchemy.orm import relationship
from database import Base
from datetime import datetime
import enum


class ProductType(str, enum.Enum):
    PHYSICAL = "physical"
    DIGITAL = "digital"
    SUBSCRIPTION = "subscription"


class DurationType(str, enum.Enum):
    MONTHLY = "monthly"
    YEARLY = "yearly"


class RenewalType(str, enum.Enum):
    YES = "yes"
    NO = "no"


class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    product_type = Column(Enum(ProductType), nullable=False)
    name = Column(String(255), index=True, nullable=False)
    base_price = Column(Float, nullable=False)
    discount = Column(Float, default=0)
    tax = Column(Float, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    order_items = relationship("OrderItem", back_populates="product")

    # ✅ added — these were missing, causing AttributeError on
    # db_product.physical_product / .digital_product / .subscription_product
    physical_product = relationship(
        "PhysicalProduct", back_populates="product", uselist=False
    )
    digital_product = relationship(
        "DigitalProduct", back_populates="product", uselist=False
    )
    subscription_product = relationship(
        "SubscriptionProduct", back_populates="product", uselist=False
    )


class PhysicalProduct(Base):
    __tablename__ = "physical_products"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    weight = Column(Float)
    stock = Column(Integer, default=0)
    warehouse = Column(String(255))

    product = relationship(
        "Product", back_populates="physical_product"
    )  # ✅ back_populates added


class DigitalProduct(Base):
    __tablename__ = "digital_products"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    file_size = Column(Float)
    download_link = Column(String(500))
    license_key = Column(String(255))

    product = relationship(
        "Product", back_populates="digital_product"
    )  # ✅ back_populates added

    def delivery(self):
        return "Instant Delivery"


class SubscriptionProduct(Base):
    __tablename__ = "subscription_products"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    duration = Column(Enum(DurationType), nullable=False)
    auto_renewal = Column(Enum(RenewalType), nullable=False)
    trial_period = Column(Integer, default=0)  # Days
    activation_date = Column(DateTime, default=datetime.utcnow)
    expiry_date = Column(DateTime, nullable=False)

    product = relationship(
        "Product", back_populates="subscription_product"
    )  # ✅ back_populates added

    def recurring_billing(self):
        return "Enabled" if self.auto_renewal == RenewalType.YES else "Disabled"


class Order(Base):
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(String(50), unique=True, nullable=False)
    customer_name = Column(String(255), nullable=False)
    customer_email = Column(String(255), nullable=False)
    total_amount = Column(Float, nullable=False)
    order_date = Column(DateTime, default=datetime.utcnow)
    status = Column(String(50), default="Pending")

    order_items = relationship("OrderItem", back_populates="order")


class OrderItem(Base):
    __tablename__ = "order_items"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    quantity = Column(Integer, nullable=False)
    price_at_purchase = Column(Float, nullable=False)

    order = relationship("Order", back_populates="order_items")
    product = relationship("Product", back_populates="order_items")
