"""CRUD operations for E-commerce API"""

from sqlalchemy.orm import Session
from fastapi import HTTPException
from models import (
    Product,
    PhysicalProduct,
    DigitalProduct,
    SubscriptionProduct,
    Order,
    OrderItem,
    ProductType,
)
from schemas import (
    PhysicalProductCreate,
    DigitalProductCreate,
    SubscriptionProductCreate,
    OrderCreate,
)
from datetime import datetime, timedelta
import uuid


# ==================== PRODUCT OPERATIONS ====================


def create_physical_product(db: Session, product: PhysicalProductCreate):
    """Create a new physical product"""
    db_product = Product(
        product_type=ProductType.PHYSICAL,
        name=product.name,
        base_price=product.base_price,
        discount=product.discount,
        tax=product.tax,
    )
    db.add(db_product)
    db.flush()

    db_physical = PhysicalProduct(
        product_id=db_product.id,
        weight=product.weight,
        stock=product.stock,
        warehouse=product.warehouse,
    )
    db.add(db_physical)
    db.commit()
    db.refresh(db_product)
    return db_product


def create_digital_product(db: Session, product: DigitalProductCreate):
    """Create a new digital product"""
    db_product = Product(
        product_type=ProductType.DIGITAL,
        name=product.name,
        base_price=product.base_price,
        discount=product.discount,
        tax=product.tax,
    )
    db.add(db_product)
    db.flush()

    db_digital = DigitalProduct(
        product_id=db_product.id,
        file_size=product.file_size,
        download_link=product.download_link,
        license_key=str(uuid.uuid4()),
    )
    db.add(db_digital)
    db.commit()
    db.refresh(db_product)
    return db_product


def create_subscription_product(db: Session, product: SubscriptionProductCreate):
    """Create a new subscription product"""
    db_product = Product(
        product_type=ProductType.SUBSCRIPTION,
        name=product.name,
        base_price=product.base_price,
        discount=product.discount,
        tax=product.tax,
    )
    db.add(db_product)
    db.flush()

    db_subscription = SubscriptionProduct(
        product_id=db_product.id,
        duration=product.duration,
        auto_renewal=product.auto_renewal,
        trial_period=product.trial_period,
        activation_date=datetime.utcnow(),
        expiry_date=datetime.utcnow() + timedelta(days=30),
    )
    db.add(db_subscription)
    db.commit()
    db.refresh(db_product)
    return db_product


def get_product_by_id(db: Session, product_id: int):
    """Get a product by ID"""
    return db.query(Product).filter(Product.id == product_id).first()


def get_all_products(db: Session, skip: int = 0, limit: int = 10):
    """Get all products with pagination"""
    return db.query(Product).offset(skip).limit(limit).all()


def get_products_by_type(
    db: Session, product_type: ProductType, skip: int = 0, limit: int = 10
):
    """Get products filtered by type"""
    return (
        db.query(Product)
        .filter(Product.product_type == product_type)
        .offset(skip)
        .limit(limit)
        .all()
    )


def update_product(db: Session, product_id: int, **kwargs):
    """Update a product"""
    db_product = db.query(Product).filter(Product.id == product_id).first()
    if not db_product:
        return None

    for key, value in kwargs.items():
        if hasattr(db_product, key):
            setattr(db_product, key, value)

    db.commit()
    db.refresh(db_product)
    return db_product


def delete_product(db: Session, product_id: int):
    """Delete a product"""
    db_product = db.query(Product).filter(Product.id == product_id).first()
    if not db_product:
        return False

    db.delete(db_product)
    db.commit()
    return True


# ==================== ORDER OPERATIONS ====================


def create_order(db: Session, order: OrderCreate):
    """Create a new order with its order items, computing totals server-side."""
    total_amount = 0
    line_items = []

    for item in order.items:
        product = db.query(Product).filter(Product.id == item.product_id).first()
        if not product:
            raise HTTPException(
                status_code=400, detail=f"Product {item.product_id} not found"
            )

        unit_price = product.base_price
        if product.discount:
            unit_price -= unit_price * (product.discount / 100)
        if product.tax:
            unit_price += unit_price * (product.tax / 100)

        total_amount += unit_price * item.quantity
        line_items.append((product.id, item.quantity, unit_price))

    try:
        db_order = Order(
            order_id=str(uuid.uuid4()),
            customer_name=order.customer_name,
            customer_email=order.customer_email,
            total_amount=total_amount,
            order_date=datetime.utcnow(),
            status="pending",
        )
        db.add(db_order)
        db.flush()  # get db_order.id without committing yet

        for product_id, quantity, unit_price in line_items:
            db_item = OrderItem(
                order_id=db_order.id,
                product_id=product_id,
                quantity=quantity,
                price_at_purchase=unit_price,  # ✅ matches real column name
            )
            db.add(db_item)

        db.commit()
        db.refresh(db_order)
        return db_order

    except Exception:
        db.rollback()
        raise


def get_order_by_id(db: Session, order_id: int):
    """Get an order by its internal integer id"""
    return db.query(Order).filter(Order.id == order_id).first()


def get_order_by_order_id(db: Session, order_id: str):
    """Get an order by its public UUID order_id (used by GET/PUT/DELETE /orders/{order_id})"""
    return db.query(Order).filter(Order.order_id == order_id).first()


def get_all_orders(db: Session, skip: int = 0, limit: int = 10):
    """Get all orders with pagination"""
    return db.query(Order).offset(skip).limit(limit).all()


def update_order_status(db: Session, order_id: int, status: str):
    """Update order status by internal integer id"""
    db_order = db.query(Order).filter(Order.id == order_id).first()
    if not db_order:
        return None

    db_order.status = status
    db.commit()
    db.refresh(db_order)
    return db_order
