import logging
import random
import uuid
from datetime import datetime, timedelta

from fastapi import FastAPI, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from config import engine, Base, get_db
from models import (
    Product,
    ProductType,
    PhysicalProduct,
    DigitalProduct,
    SubscriptionProduct,
    Order,
    OrderItem,
)
import crud
from schemas import (
    PhysicalProductCreate,
    PhysicalProductResponse,
    DigitalProductCreate,
    DigitalProductResponse,
    SubscriptionProductCreate,
    SubscriptionProductResponse,
    OrderCreate,
    OrderResponse,
)

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="E-Commerce API",
    description="Mini E-Commerce Store API with Physical, Digital, and Subscription Products",
    version="2.0.0",
)


# ==================== VALIDATION HELPERS ====================


def validate_price(price: float):
    """Validate product price"""
    if price <= 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Price must be greater than 0",
        )


def validate_discount(discount: float):
    """Validate discount percentage"""
    if discount < 0 or discount > 100:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Discount must be between 0 and 100",
        )


def validate_tax(tax: float):
    """Validate tax percentage"""
    if tax < 0 or tax > 100:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Tax must be between 0 and 100",
        )


# ==================== PHYSICAL PRODUCTS ====================


@app.post(
    "/products/physical",
    response_model=PhysicalProductResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Physical Products"],
    summary="Create a new physical product",
)
def create_physical_product(
    product: PhysicalProductCreate, db: Session = Depends(get_db)
):
    """Create a new physical product with inventory tracking"""
    try:
        validate_price(product.base_price)
        validate_discount(product.discount)
        validate_tax(product.tax)

        logger.info(f"Creating physical product: {product.name}")
        db_product = crud.create_physical_product(db, product)

        db_physical = db_product.physical_product
        return {
            "id": db_product.id,
            "product_type": db_product.product_type,
            "name": db_product.name,
            "base_price": db_product.base_price,
            "discount": db_product.discount,
            "tax": db_product.tax,
            "final_price": db_product.calculate_final_price()
            + db_physical.calculate_shipping(),
            "shipping_charge": db_physical.calculate_shipping(),
            "delivery_time": db_physical.estimate_delivery(),
            "weight": db_physical.weight,
            "stock": db_physical.stock,
            "warehouse": db_physical.warehouse,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating physical product: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error creating product",
        )


@app.get(
    "/products/physical/{product_id}",
    response_model=PhysicalProductResponse,
    tags=["Physical Products"],
)
def get_physical_product(product_id: int, db: Session = Depends(get_db)):

    db_product = (
        db.query(Product)
        .filter(Product.id == product_id, Product.product_type == ProductType.PHYSICAL)
        .first()
    )

    if not db_product:
        raise HTTPException(status_code=404, detail="Product not found")

    db_physical = db_product.physical_product

    return {
        "id": db_product.id,
        "product_type": db_product.product_type,
        "name": db_product.name,
        "base_price": db_product.base_price,
        "discount": db_product.discount,
        "tax": db_product.tax,
        "final_price": db_product.calculate_final_price()
        + db_physical.calculate_shipping(),
        "shipping_charge": db_physical.calculate_shipping(),
        "delivery_time": db_physical.estimate_delivery(),
        "weight": db_physical.weight,
        "stock": db_physical.stock,
        "warehouse": db_physical.warehouse,
    }


@app.post(
    "/products/digital",
    response_model=DigitalProductResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Digital Products"],
)
def create_digital_product(
    product: DigitalProductCreate, db: Session = Depends(get_db)
):

    if product.base_price <= 0:
        raise HTTPException(status_code=400, detail="Invalid Price")
    if product.discount < 0 or product.discount > 100:
        raise HTTPException(
            status_code=400, detail="Discount must be between 0 and 100"
        )
    if product.tax < 0:
        raise HTTPException(status_code=400, detail="Invalid Tax")

    license_key = "LIC-" + str(random.randint(10000, 99999))

    db_product = Product(
        product_type=ProductType.DIGITAL,
        name=product.name,
        base_price=product.base_price,
        discount=product.discount,
        tax=product.tax,
    )
    db.add(db_product)
    db.flush()

    db_digital = DigitalProduct(
        product_id=db_product.id,
        file_size=product.file_size,
        download_link=product.download_link,
        license_key=license_key,
    )
    db.add(db_digital)
    db.commit()
    db.refresh(db_product)

    return {
        "id": db_product.id,
        "product_type": db_product.product_type,
        "name": db_product.name,
        "base_price": db_product.base_price,
        "discount": db_product.discount,
        "tax": db_product.tax,
        "final_price": db_product.calculate_final_price(),
        "file_size": db_digital.file_size,
        "download_link": db_digital.download_link,
        "license_key": db_digital.license_key,
        "shipping_cost": db_digital.shipping_cost(),
        "delivery": db_digital.delivery(),
    }


@app.get(
    "/products/digital/{product_id}",
    response_model=DigitalProductResponse,
    tags=["Digital Products"],
)
def get_digital_product(product_id: int, db: Session = Depends(get_db)):

    db_product = (
        db.query(Product)
        .filter(Product.id == product_id, Product.product_type == ProductType.DIGITAL)
        .first()
    )

    if not db_product:
        raise HTTPException(status_code=404, detail="Product not found")

    db_digital = db_product.digital_product

    return {
        "id": db_product.id,
        "product_type": db_product.product_type,
        "name": db_product.name,
        "base_price": db_product.base_price,
        "discount": db_product.discount,
        "tax": db_product.tax,
        "final_price": db_product.calculate_final_price(),
        "file_size": db_digital.file_size,
        "download_link": db_digital.download_link,
        "license_key": db_digital.license_key,
        "shipping_cost": db_digital.shipping_cost(),
        "delivery": db_digital.delivery(),
    }


@app.post(
    "/products/subscription",
    response_model=SubscriptionProductResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["SUBSCRIPTION PRODUCTS"],
)
def create_subscription_product(
    product: SubscriptionProductCreate, db: Session = Depends(get_db)
):

    if product.base_price <= 0:
        raise HTTPException(status_code=400, detail="Invalid Price")
    if product.discount < 0 or product.discount > 100:
        raise HTTPException(
            status_code=400, detail="Discount must be between 0 and 100"
        )
    if product.tax < 0:
        raise HTTPException(status_code=400, detail="Invalid Tax")

    if product.duration not in ["Monthly", "Yearly"]:
        raise HTTPException(status_code=400, detail="Invalid Duration")

    if product.auto_renewal not in ["Yes", "No"]:
        raise HTTPException(status_code=400, detail="Invalid auto_renewal value")

    activation_date = datetime.utcnow()
    if product.duration.lower() == "monthly":
        expiry_date = activation_date + timedelta(days=30)
    else:
        expiry_date = activation_date + timedelta(days=365)

    db_product = Product(
        product_type=ProductType.SUBSCRIPTION,
        name=product.name,
        base_price=product.base_price,
        discount=product.discount,
        tax=product.tax,
    )
    db.add(db_product)
    db.flush()

    db_subscription = SubscriptionProduct(
        product_id=db_product.id,
        duration=product.duration,
        auto_renewal=product.auto_renewal,
        trial_period=product.trial_period,
        activation_date=activation_date,
        expiry_date=expiry_date,
    )
    db.add(db_subscription)
    db.commit()
    db.refresh(db_product)

    return {
        "id": db_product.id,
        "product_type": db_product.product_type,
        "name": db_product.name,
        "base_price": db_product.base_price,
        "discount": db_product.discount,
        "tax": db_product.tax,
        "final_price": db_product.calculate_final_price(),
        "duration": db_subscription.duration,
        "auto_renewal": db_subscription.auto_renewal,
        "trial_period": db_subscription.trial_period,
        "activation_date": db_subscription.activation_date,
        "expiry_date": db_subscription.expiry_date,
        "recurring_billing": db_subscription.recurring_billing(),
    }


@app.get(
    "/products/subscription/{product_id}",
    response_model=SubscriptionProductResponse,
    tags=["SUBSCRIPTION PRODUCTS"],
)
def get_subscription_product(product_id: int, db: Session = Depends(get_db)):

    db_product = (
        db.query(Product)
        .filter(
            Product.id == product_id, Product.product_type == ProductType.SUBSCRIPTION
        )
        .first()
    )

    if not db_product:
        raise HTTPException(status_code=404, detail="Product not found")

    db_subscription = db_product.subscription_product

    return {
        "id": db_product.id,
        "product_type": db_product.product_type,
        "name": db_product.name,
        "base_price": db_product.base_price,
        "discount": db_product.discount,
        "tax": db_product.tax,
        "final_price": db_product.calculate_final_price(),
        "duration": db_subscription.duration,
        "auto_renewal": db_subscription.auto_renewal,
        "trial_period": db_subscription.trial_period,
        "activation_date": db_subscription.activation_date,
        "expiry_date": db_subscription.expiry_date,
        "recurring_billing": db_subscription.recurring_billing(),
    }


@app.post(
    "/orders",
    response_model=OrderResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Orders"],
)
def create_order(order: OrderCreate, db: Session = Depends(get_db)):

    if not order.items:
        raise HTTPException(
            status_code=400, detail="Order must contain at least one item"
        )

    total_amount = 0
    order_items_list = []

    for item in order.items:
        if item.quantity <= 0:
            raise HTTPException(
                status_code=400, detail="Quantity must be greater than 0"
            )

        product = db.query(Product).filter(Product.id == item.product_id).first()

        if not product:
            raise HTTPException(
                status_code=404, detail=f"Product {item.product_id} not found"
            )

        if product.product_type == ProductType.PHYSICAL:
            physical = product.physical_product
            if item.quantity > physical.stock:
                raise HTTPException(
                    status_code=400,
                    detail=f"Not enough stock for {product.name}. Only {physical.stock} available",
                )

            physical.stock -= item.quantity

        final_price = product.calculate_final_price()
        if product.product_type == ProductType.PHYSICAL:
            final_price += product.physical_product.calculate_shipping()

        item_total = final_price * item.quantity
        total_amount += item_total

        order_items_list.append(
            {"product": product, "quantity": item.quantity, "price": final_price}
        )

    order_id = f"ORD-{uuid.uuid4().hex[:8].upper()}"

    db_order = Order(
        order_id=order_id,
        customer_name=order.customer_name,
        customer_email=order.customer_email,
        total_amount=total_amount,
        status="Pending",
    )
    db.add(db_order)
    db.flush()

    for item_data in order_items_list:
        order_item = OrderItem(
            order_id=db_order.id,
            product_id=item_data["product"].id,
            quantity=item_data["quantity"],
            price_at_purchase=item_data["price"],
        )
        db.add(order_item)

    db.commit()
    db.refresh(db_order)

    return {
        "id": db_order.id,
        "order_id": db_order.order_id,
        "customer_name": db_order.customer_name,
        "customer_email": db_order.customer_email,
        "total_amount": db_order.total_amount,
        "order_date": db_order.order_date,
        "status": db_order.status,
    }


@app.get(
    "/orders/{order_id}",
    response_model=OrderResponse,
    tags=["Orders"],
)
def get_order(order_id: str, db: Session = Depends(get_db)):

    db_order = db.query(Order).filter(Order.order_id == order_id).first()

    if not db_order:
        raise HTTPException(status_code=404, detail="Order not found")

    return {
        "id": db_order.id,
        "order_id": db_order.order_id,
        "customer_name": db_order.customer_name,
        "customer_email": db_order.customer_email,
        "total_amount": db_order.total_amount,
        "order_date": db_order.order_date,
        "status": db_order.status,
    }


@app.get("/orders", tags=["Orders"])
def list_orders(db: Session = Depends(get_db)):

    orders = db.query(Order).all()
    return orders


@app.get("/products", tags=["Products"])
def list_all_products(db: Session = Depends(get_db)):

    products = db.query(Product).all()
    result = []

    for product in products:
        if product.product_type == ProductType.PHYSICAL:
            phys = product.physical_product
            result.append(
                {
                    "id": product.id,
                    "type": "physical",
                    "name": product.name,
                    "base_price": product.base_price,
                    "discount": product.discount,
                    "tax": product.tax,
                    "final_price": product.calculate_final_price()
                    + phys.calculate_shipping(),
                    "weight": phys.weight,
                    "stock": phys.stock,
                    "warehouse": phys.warehouse,
                    "shipping_charge": phys.calculate_shipping(),
                    "delivery_time": phys.estimate_delivery(),
                }
            )

        elif product.product_type == ProductType.DIGITAL:
            dig = product.digital_product
            result.append(
                {
                    "id": product.id,
                    "type": "digital",
                    "name": product.name,
                    "base_price": product.base_price,
                    "discount": product.discount,
                    "tax": product.tax,
                    "final_price": product.calculate_final_price(),
                    "file_size": dig.file_size,
                    "download_link": dig.download_link,
                    "license_key": dig.license_key,
                    "shipping_cost": dig.shipping_cost(),
                    "delivery": dig.delivery(),
                }
            )

        elif product.product_type == ProductType.SUBSCRIPTION:
            sub = product.subscription_product
            result.append(
                {
                    "id": product.id,
                    "type": "subscription",
                    "name": product.name,
                    "base_price": product.base_price,
                    "discount": product.discount,
                    "tax": product.tax,
                    "final_price": product.calculate_final_price(),
                    "duration": sub.duration,
                    "auto_renewal": sub.auto_renewal,
                    "trial_period": sub.trial_period,
                    "activation_date": str(sub.activation_date),
                    "expiry_date": str(sub.expiry_date),
                    "recurring_billing": sub.recurring_billing(),
                }
            )

    return result


@app.put("/products/physical/{product_id}", tags=["Physical Products"])
def update_physical_product(
    product_id: int, product: PhysicalProductCreate, db: Session = Depends(get_db)
):

    db_product = (
        db.query(Product)
        .filter(Product.id == product_id, Product.product_type == ProductType.PHYSICAL)
        .first()
    )

    if not db_product:
        raise HTTPException(status_code=404, detail="Product not found")

    if product.base_price <= 0:
        raise HTTPException(status_code=400, detail="Invalid Price")
    if product.discount < 0 or product.discount > 100:
        raise HTTPException(
            status_code=400, detail="Discount must be between 0 and 100"
        )
    if product.tax < 0:
        raise HTTPException(status_code=400, detail="Invalid Tax")

    db_product.name = product.name
    db_product.base_price = product.base_price
    db_product.discount = product.discount
    db_product.tax = product.tax
    db_product.updated_at = datetime.utcnow()

    db_physical = db_product.physical_product
    db_physical.weight = product.weight
    db_physical.stock = product.stock
    db_physical.warehouse = product.warehouse

    db.commit()
    db.refresh(db_product)

    return {
        "message": "Product updated successfully",
        "id": db_product.id,
        "product_type": db_product.product_type,
        "name": db_product.name,
        "base_price": db_product.base_price,
        "discount": db_product.discount,
        "tax": db_product.tax,
        "final_price": db_product.calculate_final_price()
        + db_physical.calculate_shipping(),
        "shipping_charge": db_physical.calculate_shipping(),
        "delivery_time": db_physical.estimate_delivery(),
        "weight": db_physical.weight,
        "stock": db_physical.stock,
        "warehouse": db_physical.warehouse,
    }


@app.put(
    "/products/digital/{product_id}",
    tags=["Digital Products"],
)
def update_digital_product(
    product_id: int, product: DigitalProductCreate, db: Session = Depends(get_db)
):

    db_product = (
        db.query(Product)
        .filter(Product.id == product_id, Product.product_type == ProductType.DIGITAL)
        .first()
    )

    if not db_product:
        raise HTTPException(status_code=404, detail="Product not found")

    if product.base_price <= 0:
        raise HTTPException(status_code=400, detail="Invalid Price")
    if product.discount < 0 or product.discount > 100:
        raise HTTPException(
            status_code=400, detail="Discount must be between 0 and 100"
        )
    if product.tax < 0:
        raise HTTPException(status_code=400, detail="Invalid Tax")

    db_product.name = product.name
    db_product.base_price = product.base_price
    db_product.discount = product.discount
    db_product.tax = product.tax
    db_product.updated_at = datetime.utcnow()

    db_digital = db_product.digital_product
    db_digital.file_size = product.file_size
    db_digital.download_link = product.download_link

    db.commit()
    db.refresh(db_product)

    return {
        "message": "Product updated successfully",
        "id": db_product.id,
        "product_type": db_product.product_type,
        "name": db_product.name,
        "base_price": db_product.base_price,
        "discount": db_product.discount,
        "tax": db_product.tax,
        "final_price": db_product.calculate_final_price(),
        "file_size": db_digital.file_size,
        "download_link": db_digital.download_link,
        "license_key": db_digital.license_key,
        "shipping_cost": db_digital.shipping_cost(),
        "delivery": db_digital.delivery(),
    }


@app.put("/products/subscription/{product_id}", tags=["SUBSCRIPTION PRODUCTS"])
def update_subscription_product(
    product_id: int, product: SubscriptionProductCreate, db: Session = Depends(get_db)
):

    db_product = (
        db.query(Product)
        .filter(
            Product.id == product_id, Product.product_type == ProductType.SUBSCRIPTION
        )
        .first()
    )

    if not db_product:
        raise HTTPException(status_code=404, detail="Product not found")

    if product.base_price <= 0:
        raise HTTPException(status_code=400, detail="Invalid Price")
    if product.discount < 0 or product.discount > 100:
        raise HTTPException(
            status_code=400, detail="Discount must be between 0 and 100"
        )
    if product.tax < 0:
        raise HTTPException(status_code=400, detail="Invalid Tax")
    if product.duration not in ["Monthly", "Yearly"]:
        raise HTTPException(status_code=400, detail="Invalid Duration")
    if product.auto_renewal not in ["Yes", "No"]:
        raise HTTPException(status_code=400, detail="Invalid auto_renewal value")

    db_product.name = product.name
    db_product.base_price = product.base_price
    db_product.discount = product.discount
    db_product.tax = product.tax
    db_product.updated_at = datetime.utcnow()

    db_subscription = db_product.subscription_product
    db_subscription.duration = product.duration
    db_subscription.auto_renewal = product.auto_renewal
    db_subscription.trial_period = product.trial_period

    if product.duration.lower() == "monthly":
        db_subscription.expiry_date = db_subscription.activation_date + timedelta(
            days=30
        )
    else:
        db_subscription.expiry_date = db_subscription.activation_date + timedelta(
            days=365
        )

    db.commit()
    db.refresh(db_product)

    return {
        "message": "Product updated successfully",
        "id": db_product.id,
        "product_type": db_product.product_type,
        "name": db_product.name,
        "base_price": db_product.base_price,
        "discount": db_product.discount,
        "tax": db_product.tax,
        "final_price": db_product.calculate_final_price(),
        "duration": db_subscription.duration,
        "auto_renewal": db_subscription.auto_renewal,
        "trial_period": db_subscription.trial_period,
        "activation_date": db_subscription.activation_date,
        "expiry_date": db_subscription.expiry_date,
        "recurring_billing": db_subscription.recurring_billing(),
    }


@app.delete("/products/{product_id}", tags=["Products"])
def delete_product(product_id: int, db: Session = Depends(get_db)):

    db_product = db.query(Product).filter(Product.id == product_id).first()

    if not db_product:
        raise HTTPException(status_code=404, detail="Product not found")

    product_name = db_product.name
    product_type = db_product.product_type

    if db_product.product_type == ProductType.PHYSICAL:
        db.query(PhysicalProduct).filter(
            PhysicalProduct.product_id == product_id
        ).delete()

    elif db_product.product_type == ProductType.DIGITAL:
        db.query(DigitalProduct).filter(
            DigitalProduct.product_id == product_id
        ).delete()

    elif db_product.product_type == ProductType.SUBSCRIPTION:
        db.query(SubscriptionProduct).filter(
            SubscriptionProduct.product_id == product_id
        ).delete()

    db.delete(db_product)
    db.commit()

    return {
        "message": f"{product_type.value} product deleted successfully",
        "deleted_product": {
            "id": product_id,
            "name": product_name,
            "type": product_type.value,
        },
    }


@app.put("/orders/{order_id}", tags=["Orders"])
def update_order_status(order_id: str, status: str, db: Session = Depends(get_db)):

    valid_statuses = ["Pending", "Processing", "Shipped", "Delivered", "Cancelled"]

    if status not in valid_statuses:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid status. Must be one of: {', '.join(valid_statuses)}",
        )

    db_order = db.query(Order).filter(Order.order_id == order_id).first()

    if not db_order:
        raise HTTPException(status_code=404, detail="Order not found")

    db_order.status = status
    db.commit()
    db.refresh(db_order)

    return {
        "message": "Order status updated successfully",
        "order_id": db_order.order_id,
        "customer_name": db_order.customer_name,
        "customer_email": db_order.customer_email,
        "total_amount": db_order.total_amount,
        "order_date": db_order.order_date,
        "status": db_order.status,
    }


@app.delete("/orders/{order_id}", tags=["Orders"])
def delete_order(order_id: str, db: Session = Depends(get_db)):

    db_order = db.query(Order).filter(Order.order_id == order_id).first()

    if not db_order:
        raise HTTPException(status_code=404, detail="Order not found")

    db.query(OrderItem).filter(OrderItem.order_id == db_order.id).delete()

    db.delete(db_order)
    db.commit()

    return {
        "message": "Order deleted successfully",
        "deleted_order": {"order_id": order_id},
    }
